#include "login.h"
#include "ui_login.h"
#include "utils.h"
#include <QPropertyAnimation>
#include <QGraphicsOpacityEffect>


login::login(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::login)
{
    ui->setupUi(this);
    setWindowFlags(Qt::FramelessWindowHint | Qt::WindowSystemMenuHint);
    setWindowFlags(windowFlags() | Qt::WindowMinimizeButtonHint);
    setMouseTracking(true);
    ui->Cheatsbutton->setEnabled(false);
    ui->Profilebutton->setEnabled(false);
    ui->Cheatsbutton->setVisible(false);
    ui->Profilebutton->setVisible(false);
    ui->Usernamelb->setVisible(false);
    ui->UIUserAvatar->setVisible(false);

    QGraphicsDropShadowEffect *effect = new QGraphicsDropShadowEffect;
    effect->setBlurRadius(5);
    effect->setXOffset(5);
    effect->setYOffset(5);
    effect->setColor(Qt::black);
    ui->UILoginButton_2
    ->setGraphicsEffect(effect);

    /*username read*/
    QString val;
     QFile file;
     file.setFileName("data.js");
     file.open(QIODevice::ReadOnly | QIODevice::Text);
     val = file.readAll();
     file.close();
     qWarning() << val;
     QJsonDocument d = QJsonDocument::fromJson(val.toUtf8());
     QJsonObject sett2 = d.object();
     QString ti = d["username"].toString();
     ui->username->setText(ti);


}


void login::SelectTab(int key)
{
    if(key == 1)
    {
        ui->tabapp->setCurrentIndex(key - 1);
    }

    if(key == 2)
    {
        ui->tabapp->setCurrentIndex(key - 1);

    }

    if(key == 3)
    {
        ui->tabapp->setCurrentIndex(key - 1);

    }

}

login::~login()
{
    delete ui;
}




QJsonObject jsonObj;
QJsonDocument temp;
QJsonDocument document;














void login::on_minimize_clicked()
{
     setWindowState(Qt::WindowMinimized);
}


void login::on_exitapp_clicked()
{
     QApplication::quit();
}


void login::on_Loginbutton_clicked()
{
    SelectTab(1);
}



void login::on_homebutton_clicked()
{  SelectTab(2);

}


void login::on_UILoginButton_2_clicked()
{
    QUrl ava_url("http://localhost/apic/app.php?");
   QNetworkRequest ava_request(ava_url);
   ava_request.setRawHeader("Content-Type", "application/x-www-form-urlencoded");

   QNetworkAccessManager *manager = new QNetworkAccessManager();
   QEventLoop loop;
   QObject::connect(manager,
                    SIGNAL(finished(QNetworkReply *)),
                    &loop,
                    SLOT(quit()));
   QByteArray postData;
   postData.append("&username=" + ui->username->text());
   postData.append("&password="+ui->password->text());
   QNetworkReply* reply = manager->post(ava_request,postData);
   loop.exec();
   QString response = (QString)reply->readAll();
     temp = QJsonDocument::fromJson(response.toUtf8());
     jsonObj = temp.object();
// json stringe çevir
     QString loginstatejs = jsonObj["loginstate"].toString();
     QString userjs = jsonObj["username"].toString();
     QString bancheckjs = jsonObj["banned"].toString();
     QString useravatar = jsonObj["avatar"].toString();

     qDebug() << loginstatejs  << endl;
     qDebug() << bancheckjs  << endl;
     if(bancheckjs == "banneduser"){
       Messagebox2("You Banned");
       //islem
     }else{//  eğer login js başarılı ise ifden devam et
         if(loginstatejs == "success"){

              //json gelen veri seç ve eşleştir
             document;
             document.setObject( jsonObj );
             QByteArray bytes = document.toJson( QJsonDocument::Indented );
             QFile file( "data.js" );
             if( file.open( QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate ) )
             {
                 // tekrar yazdır data
                 QTextStream iStream( &file );
                 iStream.setCodec( "utf-8" );
                 iStream << bytes;
                 file.close();
             }//end data
             Messagebox2("login success");
             ui->Cheatsbutton->setEnabled(true);
             ui->Profilebutton->setEnabled(true);
             ui->Cheatsbutton->setVisible(true);
             ui->Profilebutton->setVisible(true);
             ui->Usernamelb->setVisible(true);
             ui->UIUserAvatar->setVisible(true);


             ui->Loginbutton->setVisible(true);
             ui->Loginbutton->setEnabled(false);

              ui->Usernamelb->setText(userjs);
              ui->UIUserAvatar->setSize(24);


              QImage avatar = DownloadImage( useravatar,35,35).toImage();

              if(avatar.bytesPerLine() < 1)
              {
                  QPixmap pixmap = QPixmap (":/darkstyle/default.png");
                  ui->UIUserAvatar->setImage(pixmap.toImage());
                  ui->UIUserAvatar->setImage(pixmap.toImage());
              }
              else
              {
                   ui->UIUserAvatar->setImage(avatar);
                   ui->UIUserAvatar->setImage(DownloadImage(useravatar,35,35).toImage());
              }

              SelectTab(2);


         }else{
             Messagebox2("login error");


         }
     }

}


void login::on_Profilebutton_clicked()
{
    SelectTab(3);
}

