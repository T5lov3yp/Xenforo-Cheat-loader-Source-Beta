#ifndef LOGIN_H
#define LOGIN_H

#include <QMainWindow>



QT_BEGIN_NAMESPACE
namespace Ui { class login; }
QT_END_NAMESPACE

class login : public QMainWindow
{
    Q_OBJECT

public:
    login(QWidget *parent = nullptr);
    ~login();

private slots:










    void on_minimize_clicked();

    void on_exitapp_clicked();

    void on_Loginbutton_clicked();





    void on_homebutton_clicked();

    void on_UILoginButton_2_clicked();

    void on_Profilebutton_clicked();

private:
    void SelectTab(int key);

    Ui::login *ui;
};
#endif // LOGIN_H
