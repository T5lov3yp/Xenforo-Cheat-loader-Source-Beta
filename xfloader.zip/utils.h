#include <QtNetwork/QNetworkAccessManager>
#include <QtNetwork/QNetworkRequest>
#include <QtNetwork/QNetworkReply>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QUrl>
#include <QEventLoop>
#include <QMessageBox>
#include <QDesktopServices>
#include <QDebug>
#include "popup.h"
#include <QFile>
#include <iostream>
#include <ctime>
#include "login.h"
#include <string_view>
#include <vector>
#include <string>
#include <QFile>
#include <QByteArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QDebug>
#include <thread>

#include <string_view>

namespace User {
QString ID;
QString Username;
QString Email;

QString Rank1;
QString Rank2;
QString VRank;

bool Admin = false;
bool Premium = false;
bool Ban = false;

QString Messagecount = 0;
QString Notificationcount = 0;

}
QString DownwloadString(QString url)
{
    QNetworkAccessManager manager;
    QNetworkReply *response = manager.get(QNetworkRequest(QUrl(url)));
    QEventLoop event;
    QObject::connect(response, SIGNAL(finished()), &event, SLOT(quit()));
    event.exec();
    QString content = response->readAll();
    return content;
}

QPixmap DownloadImage(QString url, int w,int h)
{
    QNetworkAccessManager* netAccManager = new QNetworkAccessManager;
    QNetworkRequest request(url);
    QNetworkReply *reply = netAccManager->get(request);
    QEventLoop loop;
    QObject::connect(reply, SIGNAL(finished()), &loop, SLOT(quit()));
    loop.exec();
    QByteArray bytes = reply->readAll();
    QImage img(w, h, QImage::Format_Indexed8);
    img.loadFromData(bytes);
    return QPixmap::fromImage(img);
}




void Messagebox(QString title, QString message)
{
    QMessageBox msgBox;
    msgBox.setWindowTitle(title);
    msgBox.setText(message);
    msgBox.exec();
}

void Messagebox2(QString message)
{
    PopUp *popUp;
    popUp = new PopUp();
    popUp->setPopupText(message);
    popUp->show();
}
